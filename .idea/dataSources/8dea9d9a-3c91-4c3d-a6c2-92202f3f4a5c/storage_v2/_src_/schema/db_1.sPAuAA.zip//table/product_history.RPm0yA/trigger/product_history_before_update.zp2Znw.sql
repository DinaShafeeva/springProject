create trigger product_history_BEFORE_UPDATE
  before UPDATE
  on product_history
  for each row
  BEGIN
INSERT INTO product_history (product_title, product_price) VALUES (OLD.product_title, OLD.product_price, NOW());
END;

